# Animation Package

This package provides a simple way to add animations to your web project using CSS and JavaScript. It includes support for individual animations, directional animations, rotations, and staggered animations for grouped elements.

## Installation

1. Include the CSS file in your HTML:

```html
<link rel="stylesheet" href="/animations/animation.css" />
```

2. Include the JavaScript file at the end of your HTML body:

```html
<script type="text/javascript" src="/animations/animation.js"></script>
```

## Usage

### Individual Animations

Add the `animate` class to any element you want to animate. Combine it with additional classes to specify the animation type (e.g., directional or rotational).

Example:

```html
<div class="animate animate-from-left">Slide in from left</div>
<div class="animate animate-from-bottom">Slide in from bottom</div>
<div class="animate animate-from-center animate-rotate-left">Pop + rotate</div>
```

### Staggered Animations

For grouped animations, use the `data-animate-stagger` attribute on a container element. Each child element will animate sequentially.

Example:

```html
<ul data-animate-stagger>
  <li>Item 1</li>
  <li>Item 2</li>
  <li>Item 3</li>
  <li>Item 4</li>
</ul>
```

## How It Works

- The JavaScript file uses an Intersection Observer to detect when elements enter the viewport.
- When an element is visible, the `show` class is added, triggering the animation defined in the CSS.

## Notes

- Animations are triggered only once by default. You can modify the JavaScript if you need repeated animations.
- Customize the CSS to adjust animation styles or add new ones as needed.

Enjoy creating smooth animations for your project!
